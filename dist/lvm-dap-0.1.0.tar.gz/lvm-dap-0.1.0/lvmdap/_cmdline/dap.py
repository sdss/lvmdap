#!/usr/bin/env python3

import sys, os
import time
import numpy as np
import argparse
from copy import deepcopy as copy
from pprint import pprint

# pyFIT3D dependencies
from pyFIT3D.common.auto_ssp_tools import ConfigAutoSSP, auto_ssp_elines_single_main
from pyFIT3D.common.io import clean_preview_results_files, print_time, read_spectra

from lvmdap.modelling.synthesis import StellarSynthesis

CWD = os.path.abspath(".")
EXT_CHOICES = ["CCM", "CAL"]
EXT_CURVE = "CCM"
EXT_RV = 3.1
N_MC = 20

def _no_traceback(type, value, traceback):
  print(value)

def auto_rsp_elines_rnd(
    spec_file, ssp_file, out_file, config_file, plot=None,
    error_file=None, ssp_nl_fit_file=None, sigma_inst=None, mask_list=None,
    min=None, max=None, w_min=None, w_max=None,
    nl_w_min=None, nl_w_max=None, elines_mask_file=None,
    input_redshift=None, delta_redshift=None, min_redshift=None, max_redshift=None,
    input_sigma=None, delta_sigma=None, min_sigma=None, max_sigma=None,
    input_AV=None, delta_AV=None, min_AV=None, max_AV=None, seed=None, ratio=None,
    fit_sigma_rnd=True):
    ratio = True if ratio is None else ratio
    ssp_nl_fit_file = ssp_file if ssp_nl_fit_file is None else ssp_nl_fit_file
    out_file_elines = 'elines_' + out_file
    out_file_single = 'single_' + out_file
    out_file_coeffs = 'coeffs_' + out_file
    out_file_fit = 'output.' + out_file + '.fits'
    out_file_ps = out_file
    time_ini_run = print_time(print_seed=False, get_time_only=True)
    # initial time in seconds since Epoch.
    seed = print_time() if seed is None else print_time(time_ini=seed)
    # initial time used as the seed of the random number generator.
    np.random.seed(seed)
    # read arguments
    clean_preview_results_files(out_file, out_file_elines, out_file_single, out_file_coeffs, out_file_fit)
    wl__w, f__w, ef__w = read_spectra(spec_file, f_error=lambda x: 0.1*np.sqrt(np.abs(x)))
    cf, SPS = auto_ssp_elines_single_main(
        wl__w, f__w, ef__w, ssp_file,
        config_file=config_file,
        ssp_nl_fit_file=ssp_nl_fit_file, sigma_inst=sigma_inst, out_file=out_file,
        mask_list=mask_list, elines_mask_file=elines_mask_file,
        min=min, max=max, w_min=w_min, w_max=w_max, nl_w_min=nl_w_min, nl_w_max=nl_w_max,
        input_redshift=input_redshift, delta_redshift=delta_redshift,
        min_redshift=min_redshift, max_redshift=max_redshift,
        input_sigma=input_sigma, delta_sigma=delta_sigma, min_sigma=min_sigma, max_sigma=max_sigma,
        input_AV=input_AV, delta_AV=delta_AV, min_AV=min_AV, max_AV=max_AV,
        plot=plot, single_ssp=False, ratio=ratio, fit_sigma_rnd=fit_sigma_rnd,
        sps_class=StellarSynthesis
    )
    return cf, SPS

def _main(cmd_args=sys.argv[1:]):
    parser = argparse.ArgumentParser(
        description="Run the spectral fitting procedure for the LVM"
    )
    parser.add_argument(
        "spec_file", metavar="spectrum-file",
        help="input spectrum to fit"
    )
    parser.add_argument(
        "rsp_file", metavar="rsp-file",
        help="the resolved stellar population basis"
    )
    parser.add_argument(
        "sigma_inst", metavar="sigma-inst", type=np.float,
        help="the standard deviation in wavelength of the Gaussian kernel to downgrade the resolution of the models to match the observed spectrum. This is: sigma_inst^2 = sigma_obs^2 - sigma_mod^2"
    )
    parser.add_argument(
        "label",
        help="string to label the current run"
    )
    parser.add_argument(
        "mask_file", metavar="mask-file",
        help="the file listing the wavelength ranges to exclude during the fitting"
    )
    parser.add_argument(
        "config_file", metavar="config-file",
        help="the configuration file used to set the parameters for the emission line fitting"
    )
    parser.add_argument(
        "--emission-lines-file",
        help="file containing emission lines list"
    )
    parser.add_argument(
        "--rsp-nl-file",
        help="the resolved stellar population *reduced* basis, for non-linear fitting"
    )
    parser.add_argument(
        "--plot", type=np.int,
        help="whether to plot (1) or not (0, default) the fitting procedure. If 2, a plot of the result is store in a file without display on screen",
        default=0
    )
    parser.add_argument(
        "--flux-scale", metavar=("min","max"), type=np.float, nargs=2,
        help="scale of the flux in the input spectrum",
        default=[-np.inf, +np.inf]
    )
    parser.add_argument(
        "--w-range", metavar=("wmin","wmax"), type=np.float, nargs=2,
        help="the wavelength range for the fitting procedure",
        default=[-np.inf, np.inf]
    )
    parser.add_argument(
        "--w-range-nl", metavar=("wmin2","wmax2"), type=np.float, nargs=2,
        help="the wavelength range for the *non-linear* fitting procedure"
    )

    parser.add_argument(
        "--redshift", metavar=("input_redshift","delta_redshift","min_redshift","max_redshift"), type=np.float, nargs=4,
        help="the guess, step, minimum and maximum value for the redshift during the fitting",
        default=(0.00, 0.01, 0.00, 0.30)
    )
    parser.add_argument(
        "--sigma", metavar=("input_sigma","delta_sigma","min_sigma","max_sigma"), type=np.float, nargs=4,
        help="same as the redshift, but for the line-of-sight velocity dispersion",
        default=(0, 10, 0, 450)
    )
    parser.add_argument(
        "--AV", metavar=("input_AV","delta_AV","min_AV","max_AV"), type=np.float, nargs=4,
        help="same as the redshift, but for the dust extinction in the V-band",
        default=(0.0, 0.1, 0.0, 3.0)
    )
    parser.add_argument(
        "--ext-curve",
        help=f"the extinction model to choose for the dust effects modelling. Choices are: {EXT_CHOICES}",
        choices=EXT_CHOICES, default=EXT_CURVE
    )
    parser.add_argument(
        "--RV", type=np.float,
        help=f"total to selective extinction defined as: A_V / E(B-V). Default to {EXT_RV}",
        default=EXT_RV
    )
    parser.add_argument(
        "--single-rsp",
        help="whether to fit a single stellar template to the target spectrum or not. Default to False",
        action="store_true"
    )
    parser.add_argument(
        "--n-mc", type=np.int,
        help="number of MC realisations for the spectral fitting",
        default=N_MC
    )
    parser.add_argument(
        "-o", "--output-path", metavar="path",
        help=f"path to the outputs. Defaults to '{CWD}'",
        default=CWD
    )
    parser.add_argument(
        "-c", "--clear-outputs",
        help="whether to remove or not a previous run with the same label (if present). Defaults to false",
        action="store_true"
    )
    parser.add_argument(
        "-v", "--verbose",
        help="if given, shows information about the progress of the script. Defaults to false.",
        action="store_true"
    )
    parser.add_argument(
        "-d", "--debug",
        help="debugging mode. Defaults to false.",
        action="store_true"
    )
    args = parser.parse_args(cmd_args)
    if not args.debug:
        sys.excepthook = _no_traceback
    else:
        pprint("COMMAND LINE ARGUMENTS")
        pprint(f"{args}\n")
    if args.rsp_nl_file is None:
        args.rsp_nl_file = args.rsp_file
    if args.w_range_nl is None:
        args.w_range_nl = copy(args.w_range)

    # OUTPUT NAMES ---------------------------------------------------------------------------------
    out_file_elines = os.path.join(args.output_path, f"elines_{args.label}")
    out_file_single = os.path.join(args.output_path, f"single_{args.label}")
    out_file_coeffs = os.path.join(args.output_path, f"coeffs_{args.label}")
    out_file_fit = os.path.join(args.output_path, f"output.{args.label}.fits.gz")
    out_file_ps = os.path.join(args.output_path, args.label)
    # remove previous outputs with the same label
    if args.clear_outputs:
        clean_preview_results_files(out_file_ps, out_file_elines, out_file_single, out_file_coeffs, out_file_fit)
    # ----------------------------------------------------------------------------------------------

    seed = print_time(print_seed=False, get_time_only=True)
    # initial time used as the seed of the random number generator.
    np.random.seed(seed)

    # FITTING --------------------------------------------------------------------------------------
    cf, SPS = auto_rsp_elines_rnd(
        spec_file=args.spec_file, ssp_file=args.rsp_file, ssp_nl_fit_file=args.rsp_nl_file,
        config_file=args.config_file,
        w_min=args.w_range[0], w_max=args.w_range[1], nl_w_min=args.w_range_nl[0],
        nl_w_max=args.w_range_nl[1], mask_list=args.mask_file,
        min=args.flux_scale[0], max=args.flux_scale[1], elines_mask_file=args.emission_lines_file,
        input_redshift=args.redshift[0], delta_redshift=args.redshift[1], min_redshift=args.redshift[2], max_redshift=args.redshift[3],
        input_sigma=args.sigma[0], delta_sigma=args.sigma[1], min_sigma=args.sigma[2], max_sigma=args.sigma[3],
        input_AV=args.AV[0], delta_AV=args.AV[1], min_AV=args.AV[2], max_AV=args.AV[3],
        sigma_inst=args.sigma_inst,
        out_file=args.label, plot=args.plot
    )
    # WRITE OUTPUTS --------------------------------------------------------------------------------
    SPS.output_gas_emission(filename=out_file_elines)
    if args.single_rsp:
        SPS.output_single_ssp(filename=out_file_single)
    else:
        SPS.output_fits(filename=out_file_fit)
        SPS.output_coeffs_MC(filename=out_file_coeffs)
        SPS.output(filename=out_file_ps)
