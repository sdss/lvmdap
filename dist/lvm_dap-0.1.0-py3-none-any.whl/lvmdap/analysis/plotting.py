
import itertools as it
import numpy as np

import scipy.optimize as so
from scipy.interpolate import CloughTocher2DInterpolator

from matplotlib import rc
from cycler import cycler


clist = "#114477 #117755 #E8601C #771111 #771144 #4477AA #44AA88 #F1932D #AA4477 #774411 #777711 #AA4455".split()
ccycle = cycler("color", clist)

latex_preamble = "\n".join([
    r"\usepackage{helvet}",
    r"\usepackage{amsmath}",
    r"\usepackage[helvet]{sfmath}",
    r"\renewcommand{\familydefault}{\sfdefault}"
])

font = {"family":"sans-serif", "sans-serif":"Open Sans", "size":20, "weight":300}
text = {"usetex":True, "latex.preamble":latex_preamble, "hinting":"native"}

rc("figure", figsize=(10, 10))
rc("text", **text)
# rc("font", **font)
rc("axes", linewidth=1.0, labelsize="medium", titlesize="medium", labelweight=300)#, prop_cycle=ccycle)
rc("xtick", labelsize="x-small")
rc("xtick.major", width=1.0)
rc("ytick", labelsize="x-small")
rc("ytick.major", width=1.0)
rc("lines", linewidth=2.0, markeredgewidth=0.0, markersize=7)
rc("patch", linewidth=0.0)
rc("legend", numpoints=1, scatterpoints=1, fontsize="x-small", title_fontsize="small", handletextpad=0.4, handlelength=1, handleheight=1, frameon=False)
rc("savefig", dpi=92, format="pdf")

import matplotlib.pyplot as plt
import seaborn as sns

from lvmdap.analysis.stats import weighted_pdf


def find_confidence_interval(x, pdf, confidence_level):
    """Return the difference between the integrated PDF
    ABOVE a given threshold, and a target confidence level.

    Inspired by https://bit.ly/2A63f4A

    Parameters
    ----------
    x: float
        A threshold above which the PDF will be integrated
    percent_dist: array_like
        A PDF array
    percent: float
        Target confidence interval

    Returns
    -------
    residual: float
        integral(PDF > x) - confidence_level
    """
    return pdf[pdf > x].sum() - confidence_level

def contours_from_pdf(pdf_func, range_x, range_y, deltas=0.1, percentiles=[68,95,99], return_grid=False):
    """Return the contour levels that (nearly) represent the given
    confidence interval of the PDF.

    Inspired by: https://bit.ly/2A63f4A

    Parameters
    ----------
    pdf_func: function
        The PDF function from which to draw the confidence
        intervals
    range_y, range_y: tuple
        The ranges within which calculate the support of the
        PDF.
    deltas: float, tuple
        The step of the grid If float, the step will
        be the same in x and y. If tuple, the steps
        in x and the y directions, respectively
    percentiles: tuple
        The percentiles at which to compute the levels
    return_grid: boolean
        Whether to return also the grid X, Y, Z to draw the
        contours. Defaults to False

    Returns
    -------
    levels: array_like
        The sorted array of levels
    X, Y, Z: array_like, optional
        The arrays to draw the contours as in

        >>> plt.contour(X, Y, Z, levels=levels)
    """

    if not isinstance(deltas, str) and hasattr(deltas, "__getitem__"):
        delta_x, delta_y = deltas[:2]
    elif isinstance(deltas, (float, int)):
        delta_x, delta_y = deltas, deltas

    x_grid = np.arange(*range_x, delta_x)
    y_grid = np.arange(*range_y, delta_y)
    X, Y = np.meshgrid(x_grid, y_grid)

    Z = pdf_func(X.ravel(), Y.ravel())
    Z = Z.reshape(X.shape)

    prob = Z*delta_x*delta_y
    # in some cases the PDF will not be normalized to 1.0, fix this here...
    prob /= prob.sum()

    percentiles_ = np.asarray(sorted(percentiles, reverse=True))/100
    levels = np.asarray([so.brenth(find_confidence_interval, 0.0, prob.max(), args=(prob,p)) for p in percentiles_])
    levels = levels/delta_x/delta_y

    if return_grid:
        return np.asarray(levels), X, Y, Z

    return np.asarray(levels)

def plot_triang_pdfs(pdf_params_hdus, coeffs, cmap=None, axs=None):
    """Return the PDF triangular plots and the corresponding margins, given the PDF HDU list"""

    margins = {}
    colors = []
    labels = {
        "TEFF":r"$\log{T_\text{eff}}$",
        "LOGG":r"$\log{g}$",
        "MET":r"$[\text{Fe}/\text{H}]$",
        "ALPHAM":r"$[\alpha/\text{Fe}]$"
    }
    npars = len(labels)
    if axs is None:
        _, axs = plt.subplots(npars, npars, sharex="col", sharey=False, figsize=(12,12))

    for ihdu, (i,j) in zip(range(1,len(pdf_params_hdus)), it.combinations(range(npars),2)):

        wPDF, x_scale, y_scale = weighted_pdf(pdf_params_hdus, ihdu, coeffs=coeffs)

        if i not in margins:
            mPDF = (wPDF*pdf_params_hdus[ihdu].header["CDELT2"]).sum(axis=0)
            margins[i] = (x_scale, mPDF)
        if j not in margins:
            mPDF = (wPDF*pdf_params_hdus[ihdu].header["CDELT1"]).sum(axis=1)
            margins[j] = (y_scale, mPDF)

        X, Y = np.meshgrid(x_scale, y_scale)
        wPDF_func = CloughTocher2DInterpolator(np.column_stack((X.flatten(),Y.flatten())), wPDF.flatten())
        levels, X_, Y_, PDF_ = contours_from_pdf(
            lambda x, y: wPDF_func(np.column_stack((x,y))),
            range_x=x_scale[[0,-1]],
            range_y=y_scale[[0,-1]],
            deltas=0.05, return_grid=True
        )

        x_name = pdf_params_hdus[ihdu].header["CTYPE1"]
        y_name = pdf_params_hdus[ihdu].header["CTYPE2"]

        if cmap is None:
            cmap = sns.cubehelix_palette(start=ihdu-1, reverse=True, as_cmap=True)
            colors.append(cmap.colors[0])
        else:
            colors.append(sns.color_palette(cmap)[0])
        pcm = axs[j,i].pcolormesh(X, Y, wPDF, cmap=cmap, shading="auto")
        axs[j,i].contour(X_, Y_, PDF_, levels=levels, colors="w", linewidths=1)

        mask_x = np.any(~np.isclose(wPDF, 0, rtol=0.05), axis=0)
        mask_y = np.any(~np.isclose(wPDF, 0, rtol=0.05), axis=1)
        axs[j,i].set_xlim(X_.min(), X_.max())
        axs[j,i].set_ylim(Y_.min(), Y_.max())
        if axs[j,i].is_last_row():
            axs[j,i].set_xlabel(labels[x_name])
        if axs[j,i].is_first_col():
            axs[j,i].set_ylabel(labels[y_name])
        else:
            axs[j,i].tick_params(labelleft=False)

    for i in range(npars):
        x, pdf = margins[i]
        axs[i,i].plot(x, pdf/pdf.max(), "-", color=colors[i])
        axs[i,i].tick_params(left=False, labelleft=False)
        sns.despine(ax=axs[i,i], left=True)
    for i,j in zip(*np.triu_indices_from(axs, k=1)):
        axs[i,j].set_visible(False)

    return axs
