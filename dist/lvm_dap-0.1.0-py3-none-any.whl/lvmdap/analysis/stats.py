
import numpy as np


def weighted_pdf(pdf_params_hdus, ihdu, coeffs):
    """Return the weighted PDF given the HDU list of basis PDFs and the fitting coefficients"""
    h = pdf_params_hdus[ihdu].header
    PDF = np.asarray(pdf_params_hdus[ihdu].data).T

    x_scale = np.array([h["CRVAL1"] + i*h["CDELT1"] for i in range(h["NAXIS1"])])
    y_scale = np.array([h["CRVAL2"] + i*h["CDELT2"] for i in range(h["NAXIS2"])])
    wPDF = (coeffs[None,None,:] * PDF).sum(axis=-1)

    return wPDF.T, x_scale, y_scale
